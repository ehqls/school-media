
document.addEventListener("DOMContentLoaded", () => {
  const ybsClient = window.ybsSupabase;

  const menuToggle = document.getElementById("menuToggle");
  const navigation = document.getElementById("navigation");

  const loginButton = document.getElementById("loginButton");
  const authOverlay = document.getElementById("authOverlay");
  const authClose = document.getElementById("authClose");

  const loginTab = document.getElementById("loginTab");
  const signupTab = document.getElementById("signupTab");

  const loginForm = document.getElementById("loginForm");
  const signupForm = document.getElementById("signupForm");

  const authMessage = document.getElementById("authMessage");
  const authAccount = document.getElementById("authAccount");
  const accountDetails = document.getElementById("accountDetails");
  const logoutButton = document.getElementById("logoutButton");

  if (
    !menuToggle || !navigation || !loginButton ||
    !authOverlay || !authClose || !loginTab ||
    !signupTab || !loginForm || !signupForm ||
    !authMessage || !authAccount ||
    !accountDetails || !logoutButton
  ) {
    console.error("YBS: 필요한 HTML 요소를 찾을 수 없습니다.");
    return;
  }

  function showMessage(message, type = "info") {
    authMessage.textContent = message;
    authMessage.className = "auth-message active";

    if (type === "error") authMessage.classList.add("error");
    if (type === "success") authMessage.classList.add("success");
  }

  function clearMessage() {
    authMessage.textContent = "";
    authMessage.className = "auth-message";
  }

  function openAuth() {
    authOverlay.classList.add("active");
  }

  function closeAuth() {
    authOverlay.classList.remove("active");
  }

  function changeTab(mode) {
    const isLogin = mode === "login";

    clearMessage();

    loginTab.classList.toggle("active", isLogin);
    signupTab.classList.toggle("active", !isLogin);

    loginForm.classList.toggle("active", isLogin);
    signupForm.classList.toggle("active", !isLogin);

    loginForm.style.display = isLogin ? "block" : "none";
    signupForm.style.display = isLogin ? "none" : "block";

    authAccount.classList.remove("active");
    loginTab.style.display = "";
    signupTab.style.display = "";
  }

  function showLoggedIn(profile) {
    loginButton.textContent = profile.name;
    accountDetails.textContent =
      `${profile.name} / ${profile.grade}학년 ${profile.class_number}반 ${profile.student_number}번`;

    authAccount.classList.add("active");
    loginForm.style.display = "none";
    signupForm.style.display = "none";
    loginTab.style.display = "none";
    signupTab.style.display = "none";
  }

  function showLoggedOut() {
    loginButton.textContent = "로그인";
    authAccount.classList.remove("active");
    loginForm.reset();
    signupForm.reset();
    changeTab("login");
  }

  menuToggle.addEventListener("click", () => {
    navigation.classList.toggle("active");

    menuToggle.setAttribute(
      "aria-expanded",
      String(navigation.classList.contains("active"))
    );
  });

  navigation.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", () => {
      navigation.classList.remove("active");
      menuToggle.setAttribute("aria-expanded", "false");
    });
  });

  loginButton.addEventListener("click", event => {
    event.preventDefault();
    openAuth();

    if (loginButton.textContent === "로그인") {
      changeTab("login");
    } else {
      clearMessage();
    }
  });

  authClose.addEventListener("click", closeAuth);

  authOverlay.addEventListener("click", event => {
    if (event.target === authOverlay) closeAuth();
  });

  loginTab.addEventListener("click", () => changeTab("login"));
  signupTab.addEventListener("click", () => changeTab("signup"));

  signupForm.addEventListener("submit", async event => {
    event.preventDefault();

    if (!ybsClient) {
      showMessage("Supabase 연결을 확인해 주세요.", "error");
      return;
    }

    const button = signupForm.querySelector("button[type='submit']");
    button.disabled = true;

    try {
      const name = document.getElementById("signupName").value.trim();
      const email = document.getElementById("signupEmail").value.trim();
      const password = document.getElementById("signupPassword").value;

      const grade = Number(document.getElementById("signupGrade").value);
      const classNumber = Number(document.getElementById("signupClass").value);
      const studentNumber = Number(document.getElementById("signupNumber").value);

      if (
        !name || !email || password.length < 8 ||
        ![1, 2, 3].includes(grade) ||
        !Number.isInteger(classNumber) || classNumber < 1 ||
        !Number.isInteger(studentNumber) || studentNumber < 1
      ) {
        throw new Error("입력 정보를 다시 확인해 주세요.");
      }

      const { data, error } = await ybsClient.auth.signUp({
        email,
        password,
        options: {
          data: {
            name,
            grade: String(grade),
            class_number: String(classNumber),
            student_number: String(studentNumber)
          }
        }
      });

      if (error) throw error;

      if (data.session) {
        await ybsClient.auth.signOut();
      }

      signupForm.reset();

      showMessage(
        "가입 요청이 접수되었습니다. 이메일 인증과 관리자 승인을 기다려 주세요.",
        "success"
      );

    } catch (error) {
      console.error("회원가입 오류:", error);
      showMessage(error.message, "error");

    } finally {
      button.disabled = false;
    }
  });

  loginForm.addEventListener("submit", async event => {
    event.preventDefault();

    if (!ybsClient) {
      showMessage("Supabase 연결을 확인해 주세요.", "error");
      return;
    }

    const button = loginForm.querySelector("button[type='submit']");
    button.disabled = true;

    try {
      const email = document.getElementById("loginEmail").value.trim();
      const password = document.getElementById("loginPassword").value;

      const { data, error } = await ybsClient.auth.signInWithPassword({
        email,
        password
      });

      if (error) throw error;

      const { data: profile, error: profileError } = await ybsClient
        .from("profiles")
        .select("name, grade, class_number, student_number, approval_status")
        .eq("id", data.user.id)
        .single();

      if (profileError || !profile) {
        await ybsClient.auth.signOut();
        throw new Error("회원 정보를 확인할 수 없습니다.");
      }

      if (profile.approval_status !== "approved") {
        await ybsClient.auth.signOut();

        throw new Error(
          profile.approval_status === "rejected"
            ? "가입이 승인되지 않았습니다."
            : "현재 관리자 승인 대기 중입니다."
        );
      }

      showLoggedIn(profile);
      showMessage("로그인되었습니다.", "success");

    } catch (error) {
      console.error("로그인 오류:", error);
      showMessage(error.message, "error");

    } finally {
      button.disabled = false;
    }
  });

  logoutButton.addEventListener("click", async () => {
    if (!ybsClient) return;

    logoutButton.disabled = true;

    try {
      const { error } = await ybsClient.auth.signOut();

      if (error) throw error;

      showLoggedOut();
      showMessage("로그아웃되었습니다.", "success");

    } catch (error) {
      console.error("로그아웃 오류:", error);
      showMessage("로그아웃에 실패했습니다.", "error");

    } finally {
      logoutButton.disabled = false;
    }
  });

  async function checkSession() {
    if (!ybsClient) return;

    try {
      const { data, error } = await ybsClient.auth.getSession();

      if (error) throw error;

      if (!data.session) {
        showLoggedOut();
        return;
      }

      const { data: profile, error: profileError } = await ybsClient
        .from("profiles")
        .select("name, grade, class_number, student_number, approval_status")
        .eq("id", data.session.user.id)
        .single();

      if (profileError || !profile ||
          profile.approval_status !== "approved") {
        await ybsClient.auth.signOut();
        showLoggedOut();
        return;
      }

      showLoggedIn(profile);

    } catch (error) {
      console.error("세션 확인 오류:", error);
    }
  }

  checkSession();

  console.log("YBS 회원 시스템 실행 완료");
});
