
const ybsClient = window.ybsSupabase;

const communityStatus = document.getElementById("communityStatus");
const publicPosts = document.getElementById("publicPosts");
const refreshPosts = document.getElementById("refreshPosts");

function showEmpty(message) {
  publicPosts.replaceChildren();

  const empty = document.createElement("div");
  empty.className = "community-empty";
  empty.textContent = message;

  publicPosts.appendChild(empty);
}

function createPostCard(post) {
  const card = document.createElement("article");
  card.className = "post-card";

  const title = document.createElement("h3");
  title.textContent = post.title;

  const content = document.createElement("div");
  content.className = "post-content";
  content.textContent = post.content;

  const meta = document.createElement("div");
  meta.className = "post-meta";

  const anonymous = document.createElement("span");
  anonymous.textContent = "익명";

  const date = document.createElement("span");
  date.textContent = new Date(post.created_at).toLocaleString("ko-KR");

  meta.append(anonymous, date);
  card.append(title, content, meta);

  return card;
}

async function loadPublicPosts() {
  publicPosts.textContent = "게시글을 불러오는 중입니다.";

  const { data: posts, error } = await ybsClient
    .from("community_posts")
    .select("id, title, content, created_at")
    .eq("status", "approved")
    .order("created_at", { ascending: false });

  if (error) {
    console.error("공개 게시글 조회 오류:", error);
    showEmpty("게시글을 불러오지 못했습니다.");
    return;
  }

  if (!posts || posts.length === 0) {
    showEmpty("아직 공개된 게시글이 없습니다.");
    return;
  }

  publicPosts.replaceChildren();

  posts.forEach(post => {
    publicPosts.appendChild(createPostCard(post));
  });
}

async function initializeCommunity() {
  if (!ybsClient) {
    communityStatus.textContent = "Supabase 연결을 확인할 수 없습니다.";
    showEmpty("서비스 연결을 확인해 주세요.");
    return;
  }

  try {
    const {
      data: { user },
      error: authError
    } = await ybsClient.auth.getUser();

    if (authError || !user) {
      communityStatus.textContent = "로그인이 필요합니다.";
      showEmpty("로그인 후 커뮤니티를 이용할 수 있습니다.");
      return;
    }

    const { data: profile, error: profileError } = await ybsClient
      .from("profiles")
      .select("name, approval_status")
      .eq("id", user.id)
      .single();

    if (profileError || !profile) {
      communityStatus.textContent = "회원 정보를 확인할 수 없습니다.";
      showEmpty("회원 정보를 확인할 수 없습니다.");
      return;
    }

    if (profile.approval_status !== "approved") {
      communityStatus.textContent = "관리자 승인 대기 중입니다.";
      showEmpty("회원 승인 후 게시글을 확인할 수 있습니다.");
      return;
    }

    communityStatus.textContent = `${profile.name}님, 커뮤니티에 오신 것을 환영합니다.`;

    await loadPublicPosts();

  } catch (error) {
    console.error("커뮤니티 초기화 오류:", error);
    communityStatus.textContent = "커뮤니티를 불러오지 못했습니다.";
  }
}

refreshPosts.addEventListener("click", loadPublicPosts);

initializeCommunity();
