
const adminStatus = document.getElementById("adminStatus");
const adminContent = document.getElementById("adminContent");
const memberList = document.getElementById("memberList");
const logoutButton = document.getElementById("logoutButton");

const totalMembers = document.getElementById("totalMembers");
const pendingMembers = document.getElementById("pendingMembers");
const approvedMembers = document.getElementById("approvedMembers");
const rejectedMembers = document.getElementById("rejectedMembers");

const memberSearch = document.getElementById("memberSearch");
const statusFilter = document.getElementById("statusFilter");
const refreshButton = document.getElementById("refreshButton");

const ybsClient = window.ybsSupabase;

let allMembers = [];

async function checkAdmin() {
  try {
    const {
      data: { user },
      error: authError
    } = await ybsClient.auth.getUser();

    if (authError || !user) {
      throw new Error("로그인이 필요합니다.");
    }

    const { data: profile, error: profileError } =
      await ybsClient
        .from("profiles")
        .select("name, role, approval_status")
        .eq("id", user.id)
        .single();

    if (profileError || !profile) {
      throw new Error("회원 정보를 확인할 수 없습니다.");
    }

    if (
      profile.role !== "admin" ||
      profile.approval_status !== "approved"
    ) {
      throw new Error("관리자 권한이 없습니다.");
    }

    adminStatus.textContent = `${profile.name} 관리자님, 환영합니다.`;
    adminContent.hidden = false;

    await loadMembers();

  } catch (error) {
    console.error("관리자 인증 오류:", error);
    adminStatus.textContent = error.message;
    adminContent.hidden = true;
  }
}

async function loadMembers() {
  memberList.textContent = "회원 목록을 불러오는 중입니다.";

  const { data: members, error } = await ybsClient
    .from("profiles")
    .select(
      "id, name, grade, class_number, student_number, role, approval_status, created_at"
    )
    .order("created_at", { ascending: false });

  if (error) {
    console.error("회원 목록 조회 오류:", error);
    memberList.textContent = "회원 목록을 불러오지 못했습니다.";
    return;
  }

  allMembers = members || [];

  updateStatistics();
  renderMembers();
}

function updateStatistics() {
  totalMembers.textContent = allMembers.length;

  pendingMembers.textContent = allMembers.filter(
    member => member.approval_status === "pending"
  ).length;

  approvedMembers.textContent = allMembers.filter(
    member => member.approval_status === "approved"
  ).length;

  rejectedMembers.textContent = allMembers.filter(
    member => member.approval_status === "rejected"
  ).length;
}

function renderMembers() {
  const keyword = memberSearch.value.trim().toLowerCase();
  const selectedStatus = statusFilter.value;

  const filteredMembers = allMembers.filter(member => {
    const matchesStatus =
      selectedStatus === "all" ||
      member.approval_status === selectedStatus;

    const searchableText = [
      member.name,
      `${member.grade}학년`,
      `${member.class_number}반`,
      `${member.student_number}번`
    ].join(" ").toLowerCase();

    const matchesSearch = searchableText.includes(keyword);

    return matchesStatus && matchesSearch;
  });

  memberList.replaceChildren();

  if (filteredMembers.length === 0) {
    memberList.textContent = "검색 결과가 없습니다.";
    return;
  }

  filteredMembers.forEach(member => {
    const item = document.createElement("div");
    item.className = "member-item";

    const info = document.createElement("p");

    const statusLabels = {
      pending: "승인 대기",
      approved: "승인 완료",
      rejected: "가입 거절"
    };

    const roleLabel =
      member.role === "admin" ? "관리자" : "일반 회원";

    info.textContent =
      `${member.name} | ` +
      `${member.grade}학년 ${member.class_number}반 ` +
      `${member.student_number}번 | ` +
      `${roleLabel} | ` +
      `${statusLabels[member.approval_status] || "알 수 없음"}`;

    item.appendChild(info);

    if (
      member.role !== "admin" &&
      member.approval_status === "pending"
    ) {
      const actions = document.createElement("div");
      actions.className = "member-actions";

      const approveButton = document.createElement("button");
      approveButton.textContent = "승인";
      approveButton.className = "approve-button";
      approveButton.type = "button";

      approveButton.addEventListener("click", () => {
        updateMemberStatus(member.id, "approved");
      });

      const rejectButton = document.createElement("button");
      rejectButton.textContent = "거절";
      rejectButton.className = "reject-button";
      rejectButton.type = "button";

      rejectButton.addEventListener("click", () => {
        updateMemberStatus(member.id, "rejected");
      });

      actions.append(approveButton, rejectButton);
      item.appendChild(actions);
    }

    memberList.appendChild(item);
  });
}

async function updateMemberStatus(memberId, status) {
  const action = status === "approved" ? "승인" : "거절";

  if (!confirm(`이 회원을 ${action}하시겠습니까?`)) {
    return;
  }

  const { error } = await ybsClient.rpc("set_member_approval", {
    p_member_id: memberId,
    p_status: status
  });

  if (error) {
    console.error("회원 상태 변경 오류:", error);
    alert(`${action}에 실패했습니다.`);
    return;
  }

  alert(`${action}이 완료되었습니다.`);
  await loadMembers();
}

memberSearch.addEventListener("input", renderMembers);
statusFilter.addEventListener("change", renderMembers);
refreshButton.addEventListener("click", loadMembers);

logoutButton.addEventListener("click", async () => {
  const { error } = await ybsClient.auth.signOut();

  if (error) {
    console.error("로그아웃 오류:", error);
    alert("로그아웃에 실패했습니다.");
    return;
  }

  window.location.href = "index.html";
});

if (!ybsClient) {
  adminStatus.textContent = "Supabase 연결을 확인할 수 없습니다.";
} else {
  checkAdmin();
}
