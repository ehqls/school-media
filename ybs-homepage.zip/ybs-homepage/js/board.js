
const ybsClient = window.ybsSupabase;

const boardStatus = document.getElementById("boardStatus");
const postForm = document.getElementById("postForm");
const postTitle = document.getElementById("postTitle");
const postContent = document.getElementById("postContent");
const submitPost = document.getElementById("submitPost");
const writeMessage = document.getElementById("writeMessage");

const adminModeration = document.getElementById("adminModeration");
const pendingPosts = document.getElementById("pendingPosts");
const refreshPending = document.getElementById("refreshPending");

let currentUser = null;
let currentProfile = null;

function showMessage(message, type = "") {
  writeMessage.textContent = message;
  writeMessage.className = "community-message active";

  if (type) {
    writeMessage.classList.add(type);
  }
}

function showEmpty(element, message) {
  element.replaceChildren();

  const empty = document.createElement("div");
  empty.className = "community-empty";
  empty.textContent = message;

  element.appendChild(empty);
}

function createPendingCard(post) {
  const card = document.createElement("article");
  card.className = "post-card";

  const title = document.createElement("h3");
  title.textContent = post.title;

  const content = document.createElement("div");
  content.className = "post-content";
  content.textContent = post.content;

  const meta = document.createElement("div");
  meta.className = "post-meta";

  const anonymous = document.createElement("span");
  anonymous.textContent = "익명 제출";

  const date = document.createElement("span");
  date.textContent = new Date(post.created_at).toLocaleString("ko-KR");

  meta.append(anonymous, date);

  const actions = document.createElement("div");
  actions.className = "post-actions";

  const approveButton = document.createElement("button");
  approveButton.type = "button";
  approveButton.className = "approve-button";
  approveButton.textContent = "승인";

  approveButton.addEventListener("click", () => {
    updatePostStatus(post.id, "approved");
  });

  const rejectButton = document.createElement("button");
  rejectButton.type = "button";
  rejectButton.className = "reject-button";
  rejectButton.textContent = "거절";

  rejectButton.addEventListener("click", () => {
    updatePostStatus(post.id, "rejected");
  });

  const deleteButton = document.createElement("button");
  deleteButton.type = "button";
  deleteButton.className = "delete-button";
  deleteButton.textContent = "삭제";

  deleteButton.addEventListener("click", () => {
    deletePost(post.id);
  });

  actions.append(approveButton, rejectButton, deleteButton);
  card.append(title, content, meta, actions);

  return card;
}

async function loadPendingPosts() {
  if (currentProfile?.role !== "admin") return;

  pendingPosts.textContent = "검토 목록을 불러오는 중입니다.";

  const { data: posts, error } = await ybsClient
    .from("community_posts")
    .select("id, title, content, created_at")
    .eq("status", "pending")
    .order("created_at", { ascending: true });

  if (error) {
    console.error("검토 목록 조회 오류:", error);
    showEmpty(pendingPosts, "검토 목록을 불러오지 못했습니다.");
    return;
  }

  if (!posts || posts.length === 0) {
    showEmpty(pendingPosts, "현재 검토 대기 중인 게시글이 없습니다.");
    return;
  }

  pendingPosts.replaceChildren();

  posts.forEach(post => {
    pendingPosts.appendChild(createPendingCard(post));
  });
}

async function updatePostStatus(postId, status) {
  const action = status === "approved" ? "승인" : "거절";

  if (!confirm(`이 게시글을 ${action}하시겠습니까?`)) {
    return;
  }

  const { error } = await ybsClient.rpc("set_community_post_status", {
    p_post_id: postId,
    p_status: status
  });

  if (error) {
    console.error("게시글 상태 변경 오류:", error);
    alert(`${action}에 실패했습니다.`);
    return;
  }

  alert(`${action}되었습니다.`);
  await loadPendingPosts();
}

async function deletePost(postId) {
  if (!confirm("이 게시글을 완전히 삭제하시겠습니까?")) {
    return;
  }

  const { error } = await ybsClient.rpc("delete_community_post", {
    p_post_id: postId
  });

  if (error) {
    console.error("게시글 삭제 오류:", error);
    alert("게시글 삭제에 실패했습니다.");
    return;
  }

  alert("게시글이 삭제되었습니다.");
  await loadPendingPosts();
}

postForm.addEventListener("submit", async event => {
  event.preventDefault();

  if (
    !currentUser ||
    currentProfile?.approval_status !== "approved"
  ) {
    showMessage("승인된 회원만 글을 작성할 수 있습니다.", "error");
    return;
  }

  const title = postTitle.value.trim();
  const content = postContent.value.trim();

  if (!title || !content) {
    showMessage("제목과 내용을 입력해 주세요.", "error");
    return;
  }

  submitPost.disabled = true;
  submitPost.textContent = "제출 중...";

  try {
    const { error } = await ybsClient
      .from("community_posts")
      .insert({
        author_id: currentUser.id,
        title,
        content,
        status: "pending"
      });

    if (error) throw error;

    postForm.reset();

    showMessage(
      "게시글이 제출되었습니다. 관리자 승인 후 커뮤니티에 공개됩니다.",
      "success"
    );

    if (currentProfile.role === "admin") {
      await loadPendingPosts();
    }

  } catch (error) {
    console.error("게시글 제출 오류:", error);
    showMessage("게시글 제출에 실패했습니다. 다시 시도해 주세요.", "error");

  } finally {
    submitPost.disabled = false;
    submitPost.textContent = "게시글 제출";
  }
});

async function initializeBoard() {
  if (!ybsClient) {
    boardStatus.textContent = "Supabase 연결을 확인할 수 없습니다.";
    postForm.hidden = true;
    return;
  }

  try {
    const {
      data: { user },
      error: authError
    } = await ybsClient.auth.getUser();

    if (authError || !user) {
      boardStatus.textContent = "로그인이 필요합니다.";
      postForm.hidden = true;
      return;
    }

    currentUser = user;

    const { data: profile, error: profileError } = await ybsClient
      .from("profiles")
      .select("name, role, approval_status")
      .eq("id", user.id)
      .single();

    if (profileError || !profile) {
      throw new Error("회원 정보를 확인할 수 없습니다.");
    }

    currentProfile = profile;

    if (profile.approval_status !== "approved") {
      boardStatus.textContent = "관리자 승인 후 글을 작성할 수 있습니다.";
      postForm.hidden = true;
      return;
    }

    boardStatus.textContent = `${profile.name}님, 익명 게시판입니다.`;
    postForm.hidden = false;

    if (profile.role === "admin") {
      adminModeration.hidden = false;
      await loadPendingPosts();
    }

  } catch (error) {
    console.error("게시판 초기화 오류:", error);
    boardStatus.textContent = error.message;
    postForm.hidden = true;
  }
}

refreshPending.addEventListener("click", loadPendingPosts);

initializeBoard();
